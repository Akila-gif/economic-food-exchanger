export default function Dashboard() {
    return <div>Dashboard Content</div>;
}