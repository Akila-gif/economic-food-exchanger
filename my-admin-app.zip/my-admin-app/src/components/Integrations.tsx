export default function Integrations() {
    return <div>Integrations Content</div>;
}