export default function Settings() {
    return <div>Settings Content</div>;
}