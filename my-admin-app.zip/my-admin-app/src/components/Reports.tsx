export default function Reports() {
    return <div>Reports Content</div>;
}